# Voice Math Test - Setup Instructions

## Files to Upload to GitHub:

1. `index.html` - The main app (already in your repo, replace it)
2. `api/auth.js` - Serverless function for OAuth (NEW - create `api` folder)
3. `package.json` - Project configuration (NEW)
4. `vercel.json` - Vercel configuration (already there)

## Setup Steps:

### Step 1: Get Your Google Client Secret

1. Go to: https://console.cloud.google.com/apis/credentials
2. Click on your OAuth 2.0 Client ID
3. You'll see:
   - **Client ID**: `1070671619998-eg3nrn3k9dnbqatqktu2q5knnblroq9s.apps.googleusercontent.com`
   - **Client secret**: Click "Show" to reveal it
4. **COPY the Client Secret** - you'll need it in Step 3

### Step 2: Upload Files to GitHub

1. Go to your repository: https://github.com/jaisanviswanathan-stack/Voice-to-Math
2. Create a new folder called `api`:
   - Click "Add file" → "Create new file"
   - Type: `api/auth.js`
   - Paste the contents of the `api/auth.js` file
   - Commit
3. Upload `package.json`:
   - Click "Add file" → "Upload files"
   - Upload the `package.json` file
   - Commit
4. Replace `index.html`:
   - Click on the existing `index.html`
   - Click the pencil icon to edit
   - Replace all content with the new version
   - Commit

### Step 3: Add Environment Variables to Vercel

1. Go to your Vercel dashboard: https://vercel.com/dashboard
2. Click on your "voicetomath" project
3. Click "Settings"
4. Click "Environment Variables" (left sidebar)
5. Add these variables:

   **Variable 1:**
   - Name: `GOOGLE_CLIENT_ID`
   - Value: `1070671619998-eg3nrn3k9dnbqatqktu2q5knnblroq9s.apps.googleusercontent.com`

   **Variable 2:**
   - Name: `GOOGLE_CLIENT_SECRET`
   - Value: [Paste the Client Secret you copied in Step 1]

6. Click "Save" for each

### Step 4: Redeploy

Vercel will automatically redeploy when you push to GitHub. Wait 1-2 minutes.

### Step 5: Update OAuth Settings

1. Go to: https://console.cloud.google.com/apis/credentials
2. Click your OAuth 2.0 Client ID
3. Under "Authorized redirect URIs", make sure you have:
   - `https://voicetomath.vercel.app`
4. Save

### Step 6: Test!

1. Go to: https://voicetomath.vercel.app/
2. Click "Sign in with Google"
3. It should redirect to Google, then back to your app
4. You should be signed in with Google Drive sync! 🎉

## How It Works:

- **Frontend**: Uses Google's redirect flow (no popups = no COOP issues!)
- **Backend**: Vercel serverless function exchanges the authorization code for an access token
- **Secure**: Client secret stays on the server, never exposed to the browser
